package saucedemo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class SauceDemoUItest {
    WebDriver driver;

    @BeforeClass
    public void setup() {
        // If ChromeDriver is not on your PATH, set its location:
        // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void loginTest() {
        driver.get("https://www.saucedemo.com/");

        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        // Verify successful login by checking if PRODUCTS title is displayed
        String title = driver.findElement(By.className("title")).getText();
        Assert.assertEquals(title, "PRODUCTS", "Login failed or incorrect landing page");
    }

    @Test(priority = 2)
    public void addItemToCartTest() {
        // Click "Add to cart" on first item
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

        // Verify cart count shows "1"
        String cartCount = driver.findElement(By.className("shopping_cart_badge")).getText();
        Assert.assertEquals(cartCount, "1", "Item was not added to cart");
    }

    @Test(priority = 3)
    public void verifyItemInCart() {
        // Click on cart icon
        driver.findElement(By.className("shopping_cart_link")).click();

        // Verify item is in the cart
        WebElement cartItem = driver.findElement(By.className("inventory_item_name"));
        Assert.assertEquals(cartItem.getText(), "Sauce Labs Backpack", "Wrong item in cart or item missing");
    }

    @Test(priority = 4)
    public void logoutTest() {
        // Open the menu
        driver.findElement(By.id("react-burger-menu-btn")).click();

        // Wait a moment for menu animation (not best practice — you should use WebDriverWait)
        try {
            Thread.sleep(1000);  // Use WebDriverWait in real-world testing
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Click logout
        driver.findElement(By.id("logout_sidebar_link")).click();

        // Verify redirected to login page
        String loginButtonText = driver.findElement(By.id("login-button")).getAttribute("value");
        Assert.assertEquals(loginButtonText, "Login", "Logout failed");
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}


