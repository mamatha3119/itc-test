package SwagLabsTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.Map;

public class SwagLabs3 {
    WebDriver driver;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("prefs", Map.of(
            "credentials_enable_service", false,
            "profile.password_manager_enabled", false
        ));

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
    }
    @Test
    public void checkLoginPageElementsAreEnabled() {
        WebElement usernameField = driver.findElement(By.id("user-name"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login-button"));

        Assert.assertTrue(usernameField.isEnabled(), "Username field should be enabled");
        Assert.assertTrue(passwordField.isEnabled(), "Password field should be enabled");
        Assert.assertTrue(loginButton.isEnabled(), "Login button should be enabled");
    }
    @Test
    public void testusernametrue() {
        // Locate the text box by ID
        WebElement usernameField = driver.findElement(By.id("user-name"));
        // Enter text
        String inputusername = "standard_user";
       
        usernameField .clear();
       usernameField .sendKeys("standard_user");
        // Get value and assert it
        String actualValue = usernameField .getAttribute("value");
        Assert.assertEquals(inputusername, actualValue, "Text box value not matches");
    }
    public void testpasswordtrue() {
        // Locate the text box by ID
        WebElement passwordField = driver.findElement(By.id("password"));
        // Enter text
        String inputpassword = "secret_sauce";
       
        passwordField .clear();
       passwordField .sendKeys("secret_sauce");
        // Get value and assert it
        String actualValue = passwordField .getAttribute("value");
        Assert.assertEquals(inputpassword, actualValue, "Text box value not matches");
    }
    public void testusernamefalse() {
        // Locate the text box by ID
        WebElement usernameField = driver.findElement(By.id("user-name"));
        // Enter text
        String inputusername = "standard_user";
       
        usernameField .clear();
       usernameField .sendKeys("standard_user");
        // Get value and assert it
        String actualValue = usernameField .getAttribute("value");
        Assert.assertEquals(inputusername, actualValue, "Text box value not matches");
    }
    
    public void testpasswordfalse() {
        // Locate the text box by ID
        WebElement passwordField = driver.findElement(By.id("password"));
        // Enter text
        String inputpassword = "secretsauce";
       
        passwordField .clear();
       passwordField .sendKeys("secretsauce");
        // Get value and assert it
        String actualValue = passwordField .getAttribute("value");
        Assert.assertNotEquals(inputpassword, actualValue, "Text box value  matches");
    }
    
    
    @Test
    public void login() {
    	WebElement loginButton=driver.findElement(By.id("login-button"));
    	Assert.assertEquals(loginButton.isEnabled(), "Login Button should be enabled");
    	loginButton.click();
    }
    
    	
    	
        
    @Test
    public void endToEndTest()throws InterruptedException {
        driver.get("https://www.saucedemo.com/");

        // Login
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        Thread.sleep(2000);
        
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));

        // Add product using switch case
        String productToAdd = "backpack";

        switch (productToAdd.toLowerCase()) {
            case "backpack":
                driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
                Thread.sleep(2000);
                break;
            case "bike-light":
                driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
                Thread.sleep(2000);
                break;
            case "bolt-t-shirt":
                driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();
                Thread.sleep(2000);
                break;
            default:
                System.out.println("Product not found: " + productToAdd);
                Assert.fail("Invalid product specified");
        }

        // Go to cart
        driver.findElement(By.className("shopping_cart_link")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("cart"));

        // Checkout
        driver.findElement(By.id("checkout")).click();

        // Fill in checkout info
        driver.findElement(By.id("first-name")).sendKeys("Mamatha");
        driver.findElement(By.id("last-name")).sendKeys("Baddela");
        driver.findElement(By.id("postal-code")).sendKeys("560043");
        Thread.sleep(2000);

        driver.findElement(By.id("continue")).click();
        Thread.sleep(2000);

        // Finish checkout
        driver.findElement(By.id("finish")).click();
        Thread.sleep(2000);

        // Verify order completion
        WebElement confirmation = driver.findElement(By.className("complete-header"));
        Assert.assertEquals(confirmation.getText(), "Thank you for your order!");
    }
    public void logout() throws InterruptedException {
        driver.findElement(By.id("react-burger-menu-btn")).click();
        Thread.sleep(1000); // allow menu to open
        driver.findElement(By.id("logout_sidebar_link")).click();
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}


