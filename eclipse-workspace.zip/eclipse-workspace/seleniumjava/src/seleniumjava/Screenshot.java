package seleniumjava;

import java.io.File;
import java.io.IOException;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.google.common.io.Files;
public class Screenshot {
	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("Webdriver.chrome.driver",
				"C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver-win64//chromedriver-win64/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	
		driver.manage().window().maximize();
		
		driver.get("https://google.com");
		Thread.sleep(2000);
		 WebElement searchBox = driver.findElement(By.xpath("//textarea[@id='APjFqb']"));
	        searchBox.sendKeys("cars image");
	        searchBox.sendKeys(Keys.RETURN);
	     // Take screenshot
	        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        // Save location with filename
	        File destination = new File("C:\\Users\\LabsKraft\\Pictures\\google_search.png");
	        // Copy file from temp to destination
	        Files.copy(screenshot, destination);
	     
	}
}



