package seleniumjava;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class sample3{
	public static void main(String[]args)throws InterruptedException {
		System.setProperty("webdriver.chromedriver","C:\\Users\\LabsKraft\\Downloads\\chromedriver-win64");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://the-internet.herokuapp.com/javascript_alerts");
	Thread.sleep(1000);
    // Step 2: Navigate to the dropdown page
WebElement jsAlertBtn = driver.findElement(By.xpath("//button[text()='Click for JS Alert']"));
jsAlertBtn.click();
Thread.sleep(1000);
Alert alert1 = driver.switchTo().alert();
System.out.println("Alert says: " + alert1.getText());
alert1.accept(); // Accept the alert
Thread.sleep(1000);
Alert alert2 = driver.switchTo().alert();
System.out.println("Confirmation says: " + alert2.getText());
alert2.dismiss(); // Dismiss the alert
Thread.sleep(1000);
	
WebElement jsConfirmBtn = driver.findElement(By.xpath("//button[text()='Click for JS Confirm']"));
jsConfirmBtn.click();
Thread.sleep(1000);
Alert alert3 = driver.switchTo().alert();
System.out.println("Prompt says: " + alert3.getText());
alert3.sendKeys("Selenium User");
alert3.accept(); // Accept after entering text
Thread.sleep(1000);
WebElement jsPromptBtn = driver.findElement(By.xpath("//button[text()='Click for JS Prompt']"));
jsPromptBtn.click();


// Print result text
String resultText = driver.findElement(By.id("result")).getText();
System.out.println("Final Result: " + resultText);
	}
}


