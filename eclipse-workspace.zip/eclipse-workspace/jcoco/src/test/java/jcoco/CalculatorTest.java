package jcoco;
import static org.junit.Assert.*;
import org.junit.*;
public class CalculatorTest {
	@Test
	public void testAdd() {
		calculator c = new calculator();
		assertEquals(5,c.add(2, 3));
	}
	public void testSubtract() {
		calculator c = new calculator();
		assertEquals(1,c.subtract(3, 2));
	}
	
}











