package testdouble;


public class reportservice {
	private mailservice emailservice;
	public reportservice(mailservice emailservice) {
		this.emailservice=emailservice;
}
	public String generateReport() {
		return "Report Generated";
		
	}
		
	}
	
