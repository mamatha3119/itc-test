package seleniumtestng;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.io.File;
public class BasicFormTest {
    WebDriver driver;
    @BeforeClass
    public void setUp() {
        // Set path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://testpages.herokuapp.com/styled/basic-html-form-test.html");
    }
    @Test
    public void testFillFormAndSubmit() {
        // 1. Username
        WebElement username = driver.findElement(By.name("username"));
        username.clear();
        username.sendKeys("TestUser");
        // 2. Password
        WebElement password = driver.findElement(By.name("password"));
        password.clear();
        password.sendKeys("Password123");
        // 3. Textarea (comments)
        WebElement comments = driver.findElement(By.name("comments"));
        comments.clear();
        comments.sendKeys("This is a test comment.");
        // 4. Checkboxes (select 2 checkboxes)
        WebElement checkbox1 = driver.findElement(By.cssSelector("input[name='checkboxes[]'][value='cb1']"));
        WebElement checkbox2 = driver.findElement(By.cssSelector("input[name='checkboxes[]'][value='cb3']"));
        if (!checkbox1.isSelected()) checkbox1.click();
        if (!checkbox2.isSelected()) checkbox2.click();
        // 5. Radio button (select 'rd2')
        WebElement radio2 = driver.findElement(By.cssSelector("input[name='radioval'][value='rd2']"));
        if (!radio2.isSelected()) radio2.click();
        // 6. Dropdown (select 'Drop Down Item 3')
        Select dropdown = new Select(driver.findElement(By.name("dropdown")));
        dropdown.selectByVisibleText("Drop Down Item 3");
        // 7. File upload (upload a local file)
        WebElement fileInput = driver.findElement(By.name("filename"));
        File file = new File("path/to/your/testfile.txt"); // Replace with an actual file path
        fileInput.sendKeys(file.getAbsolutePath());
        // 8. Submit button
        WebElement submitButton = driver.findElement(By.cssSelector("input[type='submit']"));
        submitButton.click();
        // Assertion: Verify that the submitted username is displayed in the results page
        WebElement usernameResult = driver.findElement(By.id("_valueusername"));
        Assert.assertEquals(usernameResult.getText(), "TestUser", "Username not submitted correctly.");
    }
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}