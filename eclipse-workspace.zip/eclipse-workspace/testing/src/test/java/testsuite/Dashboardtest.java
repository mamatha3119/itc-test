package testsuite;

import org.testng.annotations.Test;

public class Dashboardtest {
	@Test
	
	public void testValidLogin() {
		System.out.println("Dashboard Loaded");
		
	}

}
