package Button;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.Keys;
import io.github.bonigarcia.wdm.WebDriverManager;
public class Mousekeyboard {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Actions actions = new Actions(driver);
        // Part 1: Mouse actions (hover, click, double-click, right-click)
        driver.get("https://demoqa.com/buttons");
        driver.manage().window().maximize();
        Thread.sleep(1000);
        WebElement doubleClickBtn = driver.findElement(By.id("doubleClickBtn"));
        WebElement rightClickBtn = driver.findElement(By.id("rightClickBtn"));
        WebElement dynamicClickBtn = driver.findElement(By.xpath("//button[text()='Click Me']"));
        actions.doubleClick(doubleClickBtn).perform();
        Thread.sleep(500);
        actions.contextClick(rightClickBtn).perform(); // Right-click
        Thread.sleep(500);
        actions.click(dynamicClickBtn).perform();
        Thread.sleep(1000);
    
//Part 2: Keyboard input using Keys
driver.get("https://demoqa.com/text-box");
Thread.sleep(1000);
WebElement fullName = driver.findElement(By.id("userName"));
WebElement email = driver.findElement(By.id("userEmail"));
// Type with shift key (uppercase) and use Tab
actions.click(fullName)
       .keyDown(Keys.SHIFT)
       .sendKeys("selenium test")
       .keyUp(Keys.SHIFT)
       .sendKeys(Keys.TAB)
       .sendKeys("test@example.com")
       .sendKeys(Keys.TAB)
       .sendKeys("This is current address")
       .perform();
Thread.sleep(1000);
// Select all (Ctrl+A), copy (Ctrl+C), paste to next field
WebElement currAddr = driver.findElement(By.id("currentAddress"));
WebElement permAddr = driver.findElement(By.id("permanentAddress"));
currAddr.click();
actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform(); // Select all
actions.keyDown(Keys.CONTROL).sendKeys("c").keyUp(Keys.CONTROL).perform(); // Copy
actions.sendKeys(Keys.TAB).perform(); // Move to permanent address
actions.keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).perform(); // Paste
Thread.sleep(2000);
driver.quit();
    }
}















































