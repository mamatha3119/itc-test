package constructor.java;

public class Class1 {
	void m1() {
		System.out.println("m1 method");
	}
	Class1(){
		System.out.println(" 0 Arg Constructor  ");	
	}
	Class1(int a){
		System.out.println(" 1 Arg Constructor  ");	
	}
	public static void main(String[]args) {
		Class1 t = new Class1();
		t.m1();
		Class1 t1 = new Class1();
		t1.m1();
		
	
		
			
		}
	}


