package constructor.java;

public class Class3 {
	int eid;
	String ename;
	float esal;
	void disp() {
		System.out.println("Emp ID ;" +eid);
		System.out.println("Emp name ;" +ename);
		System.out.println("Emp esal ;" +esal);
		
	}
	public static void main(String[]args) {
		Class3 emp = new Class3();
		emp.disp();
	}

}

	

	
