package constructor.java;

public class Class4 {
	int eid;
	String ename;
	float esal;
Class4(){
	eid = 64;
	ename = "Mamatha";
	esal = 100000;
}
void disp() {
	System.out.println("Emp ID:" +eid);
	System.out.println("Emp name:" +ename);
	System.out.println("Emp esal:" +esal);
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class4 emp = new Class4();
		emp.disp();

	}

}
