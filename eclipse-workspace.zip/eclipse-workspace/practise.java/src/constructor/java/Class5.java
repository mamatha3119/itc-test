package constructor.java;

public class Class5 {
	int eid;
	String ename;
	float esal;
	Class5(int eid,String ename, float esal){
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		
	}
	void disp() {
		System.out.println("Emp Id :" +eid);
		System.out.println("Emp name :" +ename);
		System.out.println("Emp esal :" +esal);
		
	}
	public static void main(String[]args) {
		Class5  emp = new Class5(1001,"mamatha",10000);
		emp.disp();
		Class5  emp1 = new Class5(1002,"jessy",20000);
		emp.disp();
	}

}
