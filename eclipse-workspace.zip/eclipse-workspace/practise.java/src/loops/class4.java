package loops;

public class class4 {
	public static void main(String[] args) {
		int n =1;
		switch(n++) {
		case 1 :
			System.out.println("Hi Team");
			break;
		case 2:
			System.out.println("Hello Team");
			default:
				System.out.println("Hi Team");
			
		}
	}

}
