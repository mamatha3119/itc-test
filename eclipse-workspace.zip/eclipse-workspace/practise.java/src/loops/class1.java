package loops;

public class class1 {
	public static void main(String[]args) {
		int i =25;
		if(i==10)
			System.out.println("i is 10");
		else if(i==20)
	 {
			System.out.println("i is neither 10  nor 20");
			
	}

}
}
