package mamatha;

public class preparation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =25;
		int b = 25;
		System.out.println(a+b);
		}

}
