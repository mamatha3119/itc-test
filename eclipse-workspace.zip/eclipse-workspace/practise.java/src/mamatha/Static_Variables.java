package mamatha;

public class Static_Variables {
	static int a =1000;
	static int b = 2000;
	public static void main(String[]args) {
		System.out.println(Static_Variables.a);
		System.out.println(Static_Variables.b);
		Static_Variables t = new Static_Variables();
		t.m1();
	}
		void m1() {
			System.out.println(Static_Variables.a);
			System.out.println(Static_Variables.b);
			
		}
	}
	


