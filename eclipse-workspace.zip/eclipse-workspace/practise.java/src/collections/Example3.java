package collections;



	import java.util.*;
	public class Example3{
	public static void main(String[] args) {
	
	 // TODO Auto-generated method stub
	 List<String> topProgrammingLanguages = new ArrayList<>(); System.out.println(" Is Programming Langauge List Empty?:" + topProgrammingLanguages.isEmpty()); topProgrammingLanguages.add("C");
	 topProgrammingLanguages.add("Java");
	 topProgrammingLanguages.add("C++");
	 topProgrammingLanguages.add("python");
	 topProgrammingLanguages.add(".net");
	 topProgrammingLanguages.add(".net1");
	 // find the size of arraylist
	 System.out.println(" Here are the Top :" + topProgrammingLanguages.size() + " Programming Language In the world"); // Retrive the element at a given index
	 String bestProgrammingLang = topProgrammingLanguages.get(1);
	 System.out.println("bestProgrammingLang => " +bestProgrammingLang); // set the values
	 topProgrammingLanguages.set(4,"C#");
	 System.out.println(topProgrammingLanguages);
	 // remove 4th values
	 topProgrammingLanguages.remove(4);
	 System.out.println(topProgrammingLanguages); }}

	

	