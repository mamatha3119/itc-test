package LinkedHashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;




public class example1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     LinkedHashMap<Integer,String> num_map=new LinkedHashMap<Integer,String>();
		   num_map.put(1,"ONE");
		   num_map.put(2,"TWO");
		   num_map.put(3,"THREE");
		   num_map.put(4,"FOUR");
		   num_map.put(5,"FIVE");
		   System.out.println("The contents of LinkedHashMap:");
		   //retrieve the key-value pairs as set using entrySet & print each entry
		   for(Entry<Integer, String> m:num_map.entrySet()){
		        System.out.println(m.getKey()+" "+m.getValue());
		   }
	}


}
