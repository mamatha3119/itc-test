package staticblock;

public class class1 {
	{
		
	System.out.println("Instance Block-1");
	}
	{
		System.out.println("Instance Block-2");
	}
	static {
		System.out.println("Static Block-1");
	}
	static {
		System.out.println("Static Block-2");
	}
	class1(){
		System.out.println(" 0 arg constructor");
	}
	class1 (int a){
		System.out.println(" 1 arg constructor");
	}

		
		
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new class1();
		new class1(10);

	}

}
