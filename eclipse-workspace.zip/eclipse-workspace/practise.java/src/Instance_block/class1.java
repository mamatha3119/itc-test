package Instance_block;

public class class1 {
	class1(){
		System.out.println("0 arg constructor");
		
	}
	{
		System.out.println("Instance_block");
	}
	
		
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new class1();

	}

}
