package Arraylist;
import java.util.ArrayList;
import java.util.Scanner;

class Contact {
    private String name;
    private String surname;
    private String phoneNumber;
    private String email;
    private String place;

    public Contact(String name, String surname, String phoneNumber, String email, String place) {
        this.name = name;
        this.surname = surname;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.place = place;
    }

    @Override
    public String toString() {
        return "Name: " + name + " " + surname +
               ", Phone: " + phoneNumber +
               ", Email: " + email +
               ", Place: " + place;
    }
}

public class TelephonicDirectory {
    private ArrayList<Contact> contacts;

    public TelephonicDirectory() {
        contacts = new ArrayList<>();
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts in the directory.");
        } else {
            System.out.println("Telephone Directory:");
            for (Contact c : contacts) {
                System.out.println(c);
            }
        }
    }

    public static void main(String[] args) {
        TelephonicDirectory directory = new TelephonicDirectory();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Telephone Directory");
        char choice;
        do {
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Surname: ");
            String surname = scanner.nextLine();

            System.out.print("Enter Phone Number: ");
            String phone = scanner.nextLine();

            System.out.print("Enter Email ID: ");
            String email = scanner.nextLine();

            System.out.print("Enter Place: ");
            String place = scanner.nextLine();

            Contact contact = new Contact(name, surname, phone, email, place);
            directory.addContact(contact);

            System.out.print("Add another contact? (y/n): ");
            choice = scanner.nextLine().toLowerCase().charAt(0);

        } while (choice == 'y');

        directory.displayContacts();

        scanner.close();
    }
}





