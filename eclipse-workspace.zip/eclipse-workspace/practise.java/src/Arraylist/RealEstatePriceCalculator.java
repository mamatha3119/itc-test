package Arraylist;
public class RealEstatePriceCalculator {
    public static void main(String[] args) {
        int area = 1500; // in square feet
        int pricePerSqFt = 5000; // in INR

        double basePrice = area * pricePerSqFt;
        double registrationTax = 0.08 * basePrice;
        double gst = 0.03 * basePrice;
        double totalPrice = basePrice + registrationTax + gst;

        System.out.println("Flat Details:");
        System.out.println("Location: Prime area in Mumbai");
        System.out.println("Area: " + area + " sq ft");
        System.out.println("Price per sq ft: ₹" + pricePerSqFt);
        System.out.println("Base Price: ₹" + basePrice);
        System.out.println("Registration Tax (8%): ₹" + registrationTax);
        System.out.println("GST (3%): ₹" + gst);
        System.out.println("Total Price (Including taxes): ₹" + totalPrice);
    }
}




