package encapsulation;

public class class3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap2 car = new encap2("Toyata", 2022);
		System.out.println("Model: " + car.getModel());
		System.out.println("Year: " + car.getYear()));
		
		

	}

}
