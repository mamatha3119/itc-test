package encapsulation;

public class class2 {
	public static void main(String[]args) {
		class2 person = new class2();
	person.setName("John");
	person.setAge(30);
	S
	}
	}

}
