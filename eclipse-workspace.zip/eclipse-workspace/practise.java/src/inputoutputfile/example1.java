package inputoutputfile;
import java.io.File;
public class example1 {
    public static void main(String[] args) {
        File file = new File("C:\\Users\\LabsKraft\\Desktop\\java\\mamatha.txt");
        if (file.exists()) {
            System.out.println("File exists");
            System.out.println("Absolute Path: " + file.getAbsolutePath());
        } else {
            System.out.println("File does not exist");
        }
    }
}

