package abstraction;
import java.util.Scanner;

public class class4 {
	public static double age()
	{
		Scanner in =new Scanner(System.in);
		boolean valid = false;
		double input = 0;
		while(!valid) {
			System.out.println("Enter your age <100 : ");
			input = in.nextDouble();
			if(input>0 && input<100) {
				valid = true;
				System.out.println("This is a correct age");
			}
			else {
				System.out.println("Sorry! Invalid Input");
				
			}
		}
		return input;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double a = age();
System.out.println(a);
	}

}
