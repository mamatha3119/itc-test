package inheritance;
class Q{
	Q(){
		System.out.println(" parent 0 arg constructor ");
		
		
		
	}
}

public class class2 extends Q {
	class2()
	{
		this(10);
	System.out.println(" child 0 arg constructor ");
	
	}
	class2(int a)
	{
		super();
		System.out.println("child 1 Arg Constructor");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new class2();

	}

}
