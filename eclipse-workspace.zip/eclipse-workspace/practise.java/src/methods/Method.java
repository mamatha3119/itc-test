package methods;

public class Method {
	void m1() {
	System.out.println(" m1 Method");
	}
	static void m2() {
		System.out.println(" m2 Method");	
	}
	public static void main(String[]args) {
		Method t = new Method();
		t.m1();
		Method.m2();
	}
	

}
