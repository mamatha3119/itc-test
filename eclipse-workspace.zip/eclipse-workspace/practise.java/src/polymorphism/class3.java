package polymorphism;
class shape{
	void draw() {
		System.out.println("no shape");
	}
}
class circle extends shape{
	void draw() {
		System.out.println("Drawing Circle");
	}
}
class  rectangle extends shape{
	void draw(){
		System.out.println("Drawing rectangle");
	}
}
class triangle extends shape{
	void draw() {
		System.out.println("Drawing Triangle");
	}
}

public class class3 {
	public static void main(String[]args) {
		shape obj = new circle();
		shape obj1 = new rectangle();
		shape obj2 = new triangle();
		obj.draw();
		obj1.draw();
		obj2.draw();
	}
	
	}


