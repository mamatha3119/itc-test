package polymorphism;

public class Class2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10+20);
		System.out.println("Mamatha" + "Baddela");
		System.out.println("Mamatha" +10);
		System.out.println("Mamatha" + 10 + "Baddela");

	}

}
