package polymorphism;

public class Class1 {
	void m1(int a) {
		System.out.println("int m1 method");
			
		}
	void m1(int a, int b) {
		System.out.println("int  int m1 method");
		
	}
	void m1 (char a) {
		System.out.println("char m1 method");
	}
	public static void main(String[]args) {
			Class1 t = new Class1();
			t.m1(10);
			t.m1('v');
			t.m1(10,11);
	}
}



	
